package org.bouncycastle.mail.smime;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.util.Strings;

public class SMIMEUtil
{
    private static final String MULTIPART = "multipart";
    private static final int BUF_SIZE = 32760;

    public static boolean isMultipartContent(Part part)
        throws MessagingException
    {
        String partType = Strings.toLowerCase(part.getContentType());

        return partType.startsWith(MULTIPART);
    }

    static boolean isCanonicalisationRequired(
        MimeBodyPart bodyPart,
        String defaultContentTransferEncoding)
        throws MessagingException
    {
        String[] cte = bodyPart.getHeader("Content-Transfer-Encoding");
        String contentTransferEncoding;

        if (cte == null)
        {
            contentTransferEncoding = defaultContentTransferEncoding;
        }
        else
        {
            contentTransferEncoding = cte[0];
        }

        return !contentTransferEncoding.equalsIgnoreCase("binary");
    }

    static class LineOutputStream
        extends FilterOutputStream
    {
        private static byte newline[];

        public LineOutputStream(OutputStream outputstream)
        {
            super(outputstream);
        }

        public void writeln(String s)
            throws MessagingException
        {
            try
            {
                byte abyte0[] = Strings.toByteArray(s);
                super.out.write(abyte0);
                super.out.write(newline);
            }
            catch (Exception exception)
            {
                throw new MessagingException("IOException", exception);
            }
        }

        public void writeln()
            throws MessagingException
        {
            try
            {
                super.out.write(newline);
            }
            catch (Exception exception)
            {
                throw new MessagingException("IOException", exception);
            }
        }

        static
        {
            newline = new byte[2];
            newline[0] = 13;
            newline[1] = 10;
        }
    }

    /**
     * internal preamble is generally included in signatures, while this is technically wrong,
     * if we find internal preamble we include it by default.
     */
    static void outputPreamble(LineOutputStream lOut, MimeBodyPart part, String boundary)
        throws MessagingException, IOException
    {
        InputStream rawIn;

        try
        {
            rawIn = part.getRawInputStream();
        }
        catch (MessagingException e)
        {
            return;   // no underlying content rely on default generation
        }

        CountingInputStream in = new CountingInputStream(rawIn);
        String line;
        String lastLine = null;

        while ((line = readLine(in)) != null)
        {
            if (line.equals(boundary))
            {
                break;
            }

            if (line.length() != 0)
            {
                lastLine = line;
            }

            lOut.writeln(line);
        }

        in.close();

        if (line == null)
        {
            throw new SMIMEBoundaryNotFoundException("no boundary found for: ", boundary,
                safeContentType(part), safeContentDisposition(part), 1, 0, in.getCount(), lastLine);
        }
    }

    /**
     * internal postamble is generally included in signatures, while this is technically wrong,
     * if we find internal postamble we include it by default.
     */
    static void outputPostamble(LineOutputStream lOut, MimeBodyPart part, int count, String boundary)
        throws MessagingException, IOException
    {
        InputStream rawIn;

        try
        {
            rawIn = part.getRawInputStream();
        }
        catch (MessagingException e)
        {
            return;   // no underlying content rely on default generation
        }

        CountingInputStream in = new CountingInputStream(rawIn);
        String line;
        String lastLine = null;
        int boundaries = count + 1;

        while ((line = readLine(in)) != null)
        {
            if (line.length() != 0)
            {
                lastLine = line;
            }

            if (line.startsWith(boundary))
            {
                boundaries--;

                if (boundaries == 0)
                {
                    break;
                }
            }
        }

        while ((line = readLine(in)) != null)
        {
            lOut.writeln(line);
        }

        in.close();

        if (boundaries != 0)
        {
            throw new SMIMEBoundaryNotFoundException("all boundaries not found for: ", boundary,
                safeContentType(part), safeContentDisposition(part), count + 1, count + 1 - boundaries,
                in.getCount(), lastLine);
        }
    }

    /**
     * Return the part's Content-Type for diagnostics, unfolded, or null if it
     * cannot be read - a header failure must not mask the original error.
     */
    private static String safeContentType(MimeBodyPart part)
    {
        try
        {
            return unfold(part.getContentType());
        }
        catch (MessagingException e)
        {
            return null;
        }
    }

    /**
     * Return the part's Content-Disposition for diagnostics, unfolded, or
     * null if absent or unreadable.
     */
    private static String safeContentDisposition(MimeBodyPart part)
    {
        try
        {
            String[] disposition = part.getHeader("Content-Disposition");

            return (disposition != null && disposition.length > 0) ? unfold(disposition[0]) : null;
        }
        catch (MessagingException e)
        {
            return null;
        }
    }

    private static String unfold(String header)
    {
        if (header == null || (header.indexOf('\r') < 0 && header.indexOf('\n') < 0))
        {
            return header;
        }

        StringBuilder sb = new StringBuilder(header.length());
        for (int i = 0; i != header.length(); i++)
        {
            char ch = header.charAt(i);
            if (ch != '\r' && ch != '\n')
            {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    /**
     * Counts the bytes consumed from the underlying raw stream so boundary
     * scan failures can report how far they got.
     */
    private static class CountingInputStream
        extends InputStream
    {
        private final InputStream in;
        private long count;

        CountingInputStream(InputStream in)
        {
            this.in = in;
        }

        public int read()
            throws IOException
        {
            int b = in.read();
            if (b >= 0)
            {
                count++;
            }
            return b;
        }

        public int read(byte[] buf, int off, int len)
            throws IOException
        {
            int numRead = in.read(buf, off, len);
            if (numRead > 0)
            {
                count += numRead;
            }
            return numRead;
        }

        public void close()
            throws IOException
        {
            in.close();
        }

        long getCount()
        {
            return count;
        }
    }

    /*
     * Write the bytes between an inner multipart child's closing boundary and the
     * next outer boundary into the digest input. When the parent body part was
     * parsed from bytes, the raw stream is consulted so any extra postamble lines
     * the original signer included in its digest input are preserved. When the
     * parent was constructed in-memory (no raw stream), the signing side
     * (SMIMESignedGenerator.ContentSigner.writeBodyPart) emits exactly one CRLF
     * between the inner closing boundary and the next outer boundary, so the same
     * single CRLF is emitted here. Earlier versions returned silently in the
     * in-memory case, producing a digest input one CRLF short of what the signer
     * hashed (github #542).
     */
    static void outputPostamble(LineOutputStream lOut, BodyPart parent, String parentBoundary, BodyPart part)
        throws MessagingException, IOException
    {
        InputStream in;

        try
        {
            in = ((MimeBodyPart)parent).getRawInputStream();
        }
        catch (MessagingException e)
        {
            lOut.writeln();
            return;
        }


        MimeMultipart multipart = (MimeMultipart)part.getContent();
        ContentType contentType = new ContentType(multipart.getContentType());
        String boundary = "--" + contentType.getParameter("boundary");
        int count = multipart.getCount() + 1;
        String line;
        while (count != 0 && (line = readLine(in)) != null)
        {
            if (line.startsWith(boundary))
            {
                count--;
            }
        }

        while ((line = readLine(in)) != null)
        {
            if (line.startsWith(parentBoundary))
            {
                break;
            }
            lOut.writeln(line);
        }

        in.close();
    }

    /*
     * read a line of input stripping of the tailing \r\n
     */
    private static String readLine(InputStream in)
        throws IOException
    {
        StringBuilder b = new StringBuilder();

        int ch;
        while ((ch = in.read()) >= 0 && ch != '\n')
        {
            if (ch != '\r')
            {
                b.append((char)ch);
            }
        }

        if (ch < 0 && b.length() == 0)
        {
            return null;
        }

        return b.toString();
    }

    static void outputBodyPart(
        OutputStream out,
        boolean topLevel,
        BodyPart bodyPart,
        String defaultContentTransferEncoding)
        throws MessagingException, IOException
    {
        if (bodyPart instanceof MimeBodyPart)
        {
            MimeBodyPart mimePart = (MimeBodyPart)bodyPart;
            String[] cte = mimePart.getHeader("Content-Transfer-Encoding");
            String contentTransferEncoding;

            if (isMultipartContent(mimePart))
            {
                Multipart mp = SMIMEUtil.getMultipart(mimePart);
                String boundary = "--" + new ContentType(mp.getContentType()).getParameter("boundary");
                SMIMEUtil.LineOutputStream lOut = SMIMEUtil.writeMultipartContentBodyPart(out, mimePart, boundary);

                for (int i = 0; i < mp.getCount(); i++)
                {
                    lOut.writeln(boundary);
                    BodyPart part = mp.getBodyPart(i);
                    outputBodyPart(out, false, part, defaultContentTransferEncoding);
                    if (!isMultipartContent(part))
                    {
                        lOut.writeln();       // CRLF terminator needed
                    }
                    else
                    {                        // output nested postamble
                        outputPostamble(lOut, mimePart, boundary, part);
                    }
                }

                lOut.writeln(boundary + "--");

                if (topLevel)
                {
                    outputPostamble(lOut, mimePart, mp.getCount(), boundary);
                }

                return;
            }

            if (cte == null)
            {
                contentTransferEncoding = defaultContentTransferEncoding;
            }
            else
            {
                contentTransferEncoding = cte[0];
            }

            if (!contentTransferEncoding.equalsIgnoreCase("base64")
                && !contentTransferEncoding.equalsIgnoreCase("quoted-printable"))
            {
                if (!contentTransferEncoding.equalsIgnoreCase("binary"))
                {
                    out = new CRLFOutputStream(out);
                }
                bodyPart.writeTo(out);
                out.flush();
                return;
            }

            boolean base64 = contentTransferEncoding.equalsIgnoreCase("base64");

            //
            // Write raw content, performing canonicalization
            //
            InputStream inRaw;

            try
            {
                inRaw = mimePart.getRawInputStream();
            }
            catch (MessagingException e)
            {
                // this is less than ideal, but if the raw output stream is unavailable it's the
                // best option we've got.
                out = new CRLFOutputStream(out);
                bodyPart.writeTo(out);
                out.flush();
                return;
            }

            //
            // Write headers
            //
            LineOutputStream outLine = new LineOutputStream(out);
            for (Enumeration e = mimePart.getAllHeaderLines(); e.hasMoreElements(); )
            {
                String header = (String)e.nextElement();

                outLine.writeln(header);
            }

            outLine.writeln();
            outLine.flush();


            OutputStream outCRLF;

            if (base64)
            {
                outCRLF = new Base64CRLFOutputStream(out);
            }
            else
            {
                outCRLF = new CRLFOutputStream(out);
            }

            byte[] buf = new byte[BUF_SIZE];

            int len;
            while ((len = inRaw.read(buf, 0, buf.length)) > 0)
            {

                outCRLF.write(buf, 0, len);
            }

            inRaw.close();

            outCRLF.flush();
        }
        else
        {
            if (!defaultContentTransferEncoding.equalsIgnoreCase("binary"))
            {
                out = new CRLFOutputStream(out);
            }

            bodyPart.writeTo(out);

            out.flush();
        }
    }

    /**
     * return the MimeBodyPart described in the raw bytes provided in content
     */
    public static MimeBodyPart toMimeBodyPart(
        byte[] content)
        throws SMIMEException
    {
        return toMimeBodyPart(new ByteArrayInputStream(content));
    }

    /**
     * return the MimeBodyPart described in the input stream content
     */
    public static MimeBodyPart toMimeBodyPart(
        InputStream content)
        throws SMIMEException
    {
        try
        {
            return new MimeBodyPart(content);
        }
        catch (MessagingException e)
        {
            throw new SMIMEException("exception creating body part.", e);
        }
    }

    static FileBackedMimeBodyPart toWriteOnceBodyPart(
        CMSTypedStream content)
        throws SMIMEException
    {
        try
        {
            return new WriteOnceFileBackedMimeBodyPart(content.getContentStream(), TempFileFactory.createTempFile("bcMail", ".mime"));
        }
        catch (IOException e)
        {
            throw new SMIMEException("IOException creating tmp file:" + e.getMessage(), e);
        }
        catch (MessagingException e)
        {
            throw new SMIMEException("can't create part: " + e, e);
        }
    }

    /**
     * return a file backed MimeBodyPart described in {@link CMSTypedStream} content.
     */
    public static FileBackedMimeBodyPart toMimeBodyPart(
        CMSTypedStream content)
        throws SMIMEException
    {
        try
        {
            return toMimeBodyPart(content, TempFileFactory.createTempFile("bcMail", ".mime"));
        }
        catch (IOException e)
        {
            throw new SMIMEException("IOException creating tmp file:" + e.getMessage(), e);
        }
    }

    /**
     * Return a file based MimeBodyPart represented by content and backed
     * by the file represented by file.
     *
     * @param content content stream containing body part.
     * @param file    file to store the decoded body part in.
     * @return the decoded body part.
     * @throws SMIMEException
     */
    public static FileBackedMimeBodyPart toMimeBodyPart(
        CMSTypedStream content,
        File file)
        throws SMIMEException
    {
        try
        {
            return new FileBackedMimeBodyPart(content.getContentStream(), file);
        }
        catch (IOException e)
        {
            throw new SMIMEException("can't save content to file: " + e, e);
        }
        catch (MessagingException e)
        {
            throw new SMIMEException("can't create part: " + e, e);
        }
    }

    /**
     * Return a CMS IssuerAndSerialNumber structure for the passed in X.509 certificate.
     *
     * @param cert the X.509 certificate to get the issuer and serial number for.
     * @return an IssuerAndSerialNumber structure representing the certificate.
     */
    public static IssuerAndSerialNumber createIssuerAndSerialNumberFor(
        X509Certificate cert)
        throws CertificateParsingException
    {
        try
        {
            return new IssuerAndSerialNumber(new JcaX509CertificateHolder(cert).getIssuer(), cert.getSerialNumber());
        }
        catch (Exception e)
        {
            throw new CertificateParsingException("exception extracting issuer and serial number: " + e);
        }
    }

    private static class WriteOnceFileBackedMimeBodyPart
        extends FileBackedMimeBodyPart
    {
        public WriteOnceFileBackedMimeBodyPart(InputStream content, File file)
            throws MessagingException, IOException
        {
            super(content, file);
        }

        public void writeTo(OutputStream out)
            throws MessagingException, IOException
        {
            super.writeTo(out);

            this.dispose();
        }
    }

    static class Base64CRLFOutputStream
        extends FilterOutputStream
    {
        protected int lastb;
        protected static byte newline[];
        private boolean isCrlfStream;

        public Base64CRLFOutputStream(OutputStream outputstream)
        {
            super(outputstream);
            lastb = -1;
        }

        public void write(int i)
            throws IOException
        {
            if (i == '\r')
            {
                out.write(newline);
            }
            else if (i == '\n')
            {
                if (lastb != '\r')
                {                                 // imagine my joy...
                    if (!(isCrlfStream && lastb == '\n'))
                    {
                        out.write(newline);
                    }
                }
                else
                {
                    isCrlfStream = true;
                }
            }
            else
            {
                out.write(i);
            }

            lastb = i;
        }

        public void write(byte[] buf)
            throws IOException
        {
            this.write(buf, 0, buf.length);
        }

        public void write(byte buf[], int off, int len)
            throws IOException
        {
            for (int i = off; i != off + len; i++)
            {
                this.write(buf[i]);
            }
        }

        public void writeln()
            throws IOException
        {
            super.out.write(newline);
        }

        static
        {
            newline = new byte[2];
            newline[0] = '\r';
            newline[1] = '\n';
        }
    }

    static InputStream getInputStream(
        Part bodyPart,
        int bufferSize)
        throws MessagingException
    {
        try
        {
            InputStream in = bodyPart.getInputStream();

            if (bufferSize == 0)
            {
                return new BufferedInputStream(in);
            }
            else
            {
                return new BufferedInputStream(in, bufferSize);
            }
        }
        catch (IOException e)
        {
            throw new MessagingException("can't extract input stream: " + e);
        }
    }

    static Multipart getMultipart(MimeBodyPart bodyPart)
        throws MessagingException, IOException
    {
        Object content = bodyPart.getContent();
        Multipart mp;
        if (content instanceof Multipart)
        {
            mp = (Multipart)content;
        }
        else
        {
            mp = new MimeMultipart(bodyPart.getDataHandler().getDataSource());
        }
        return mp;
    }

    static LineOutputStream writeMultipartContentBodyPart(OutputStream out, MimeBodyPart bodyPart, String boundary)
        throws MessagingException, IOException
    {

        LineOutputStream lOut = new LineOutputStream(out);

        Enumeration headers = bodyPart.getAllHeaderLines();
        while (headers.hasMoreElements())
        {
            lOut.writeln((String)headers.nextElement());
        }

        lOut.writeln();      // CRLF separator

        outputPreamble(lOut, bodyPart, boundary);
        return lOut;
    }

    static void closeStreamSafely(InputStream sigStream)
    {
        try
        {
            if (sigStream != null)
            {
                sigStream.close();
            }
        }
        catch (IOException ioEx)
        {
            // Ignore secondary exception during cleanup
        }
    }

    /**
     * Interface to obfuscate the repetitive constructors so that we could have only one createSafe
     */
    public interface SafeCreator
    {
        Object create() throws Exception;
    }

    /**
     * If getInputStreamNoMultipartSigned returns PipedInputStream it will lead to
     * resource leak as it will not be closed if not handled safely. This method will initiate
     * SMIMESigned but if it fails, it will close PipedInputStream
     * 
     * @throws MessagingException an error extracting the signature or
     * otherwise processing the message.
     * @throws CMSException if some other problem occurs.
     */
    public static Object createSafe(InputStream sigStream, SafeCreator creator)
        throws MessagingException, CMSException 
    {
        try
        {
            return creator.create();
        }
        catch (Exception e)
        {
            closeStreamSafely(sigStream);
            
            // Handle re-throwing consistently
            if (e instanceof MessagingException) throw (MessagingException)e;
            if (e instanceof CMSException) throw (CMSException)e;
            if (e instanceof RuntimeException) throw (RuntimeException)e;
            throw new CMSException("Exception creating safe instance: " + e.getMessage(), e);
        }
    }

    static InputStream getInputStreamNoMultipartSigned(
        Part bodyPart)
        throws MessagingException
    {
        try
        {
            if (bodyPart.isMimeType("multipart/signed"))
            {
                throw new MessagingException("attempt to create signed data object from multipart content - use MimeMultipart constructor.");
            }

            return bodyPart.getInputStream();
        }
        catch (IOException e)
        {
            throw new MessagingException("can't extract input stream: " + e);
        }
    }

    static InputStream getInputStream(
        Part    bodyPart)
        throws MessagingException
    {
        try
        {
            return bodyPart.getInputStream();
        }
        catch (IOException e)
        {
            throw new MessagingException("can't extract input stream: " + e);
        }
    }

    static void messageSaveChanges(MimeMessage message)
        throws SMIMEException
    {
        try
        {
            message.saveChanges();      // make sure we're up to date.
        }
        catch (MessagingException e)
        {
            throw new SMIMEException("unable to save message", e);
        }
    }
}
