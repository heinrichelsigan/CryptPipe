package mls_client;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * A wrapper around an MLS client implementation
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.58.0)",
    comments = "Source: mls_client.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class MLSClientGrpc {

  private MLSClientGrpc() {}

  public static final java.lang.String SERVICE_NAME = "mls_client.MLSClient";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.NameRequest,
      mls_client.MlsClient.NameResponse> getNameMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Name",
      requestType = mls_client.MlsClient.NameRequest.class,
      responseType = mls_client.MlsClient.NameResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.NameRequest,
      mls_client.MlsClient.NameResponse> getNameMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.NameRequest, mls_client.MlsClient.NameResponse> getNameMethod;
    if ((getNameMethod = MLSClientGrpc.getNameMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getNameMethod = MLSClientGrpc.getNameMethod) == null) {
          MLSClientGrpc.getNameMethod = getNameMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.NameRequest, mls_client.MlsClient.NameResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Name"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.NameRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.NameResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Name"))
              .build();
        }
      }
    }
    return getNameMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.SupportedCiphersuitesRequest,
      mls_client.MlsClient.SupportedCiphersuitesResponse> getSupportedCiphersuitesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SupportedCiphersuites",
      requestType = mls_client.MlsClient.SupportedCiphersuitesRequest.class,
      responseType = mls_client.MlsClient.SupportedCiphersuitesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.SupportedCiphersuitesRequest,
      mls_client.MlsClient.SupportedCiphersuitesResponse> getSupportedCiphersuitesMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.SupportedCiphersuitesRequest, mls_client.MlsClient.SupportedCiphersuitesResponse> getSupportedCiphersuitesMethod;
    if ((getSupportedCiphersuitesMethod = MLSClientGrpc.getSupportedCiphersuitesMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getSupportedCiphersuitesMethod = MLSClientGrpc.getSupportedCiphersuitesMethod) == null) {
          MLSClientGrpc.getSupportedCiphersuitesMethod = getSupportedCiphersuitesMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.SupportedCiphersuitesRequest, mls_client.MlsClient.SupportedCiphersuitesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SupportedCiphersuites"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.SupportedCiphersuitesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.SupportedCiphersuitesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("SupportedCiphersuites"))
              .build();
        }
      }
    }
    return getSupportedCiphersuitesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CreateGroupRequest,
      mls_client.MlsClient.CreateGroupResponse> getCreateGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateGroup",
      requestType = mls_client.MlsClient.CreateGroupRequest.class,
      responseType = mls_client.MlsClient.CreateGroupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CreateGroupRequest,
      mls_client.MlsClient.CreateGroupResponse> getCreateGroupMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CreateGroupRequest, mls_client.MlsClient.CreateGroupResponse> getCreateGroupMethod;
    if ((getCreateGroupMethod = MLSClientGrpc.getCreateGroupMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getCreateGroupMethod = MLSClientGrpc.getCreateGroupMethod) == null) {
          MLSClientGrpc.getCreateGroupMethod = getCreateGroupMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CreateGroupRequest, mls_client.MlsClient.CreateGroupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateGroupResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("CreateGroup"))
              .build();
        }
      }
    }
    return getCreateGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CreateKeyPackageRequest,
      mls_client.MlsClient.CreateKeyPackageResponse> getCreateKeyPackageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateKeyPackage",
      requestType = mls_client.MlsClient.CreateKeyPackageRequest.class,
      responseType = mls_client.MlsClient.CreateKeyPackageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CreateKeyPackageRequest,
      mls_client.MlsClient.CreateKeyPackageResponse> getCreateKeyPackageMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CreateKeyPackageRequest, mls_client.MlsClient.CreateKeyPackageResponse> getCreateKeyPackageMethod;
    if ((getCreateKeyPackageMethod = MLSClientGrpc.getCreateKeyPackageMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getCreateKeyPackageMethod = MLSClientGrpc.getCreateKeyPackageMethod) == null) {
          MLSClientGrpc.getCreateKeyPackageMethod = getCreateKeyPackageMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CreateKeyPackageRequest, mls_client.MlsClient.CreateKeyPackageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateKeyPackage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateKeyPackageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateKeyPackageResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("CreateKeyPackage"))
              .build();
        }
      }
    }
    return getCreateKeyPackageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.JoinGroupRequest,
      mls_client.MlsClient.JoinGroupResponse> getJoinGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "JoinGroup",
      requestType = mls_client.MlsClient.JoinGroupRequest.class,
      responseType = mls_client.MlsClient.JoinGroupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.JoinGroupRequest,
      mls_client.MlsClient.JoinGroupResponse> getJoinGroupMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.JoinGroupRequest, mls_client.MlsClient.JoinGroupResponse> getJoinGroupMethod;
    if ((getJoinGroupMethod = MLSClientGrpc.getJoinGroupMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getJoinGroupMethod = MLSClientGrpc.getJoinGroupMethod) == null) {
          MLSClientGrpc.getJoinGroupMethod = getJoinGroupMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.JoinGroupRequest, mls_client.MlsClient.JoinGroupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "JoinGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.JoinGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.JoinGroupResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("JoinGroup"))
              .build();
        }
      }
    }
    return getJoinGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalJoinRequest,
      mls_client.MlsClient.ExternalJoinResponse> getExternalJoinMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExternalJoin",
      requestType = mls_client.MlsClient.ExternalJoinRequest.class,
      responseType = mls_client.MlsClient.ExternalJoinResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalJoinRequest,
      mls_client.MlsClient.ExternalJoinResponse> getExternalJoinMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalJoinRequest, mls_client.MlsClient.ExternalJoinResponse> getExternalJoinMethod;
    if ((getExternalJoinMethod = MLSClientGrpc.getExternalJoinMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getExternalJoinMethod = MLSClientGrpc.getExternalJoinMethod) == null) {
          MLSClientGrpc.getExternalJoinMethod = getExternalJoinMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ExternalJoinRequest, mls_client.MlsClient.ExternalJoinResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExternalJoin"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExternalJoinRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExternalJoinResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ExternalJoin"))
              .build();
        }
      }
    }
    return getExternalJoinMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.GroupInfoRequest,
      mls_client.MlsClient.GroupInfoResponse> getGroupInfoMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GroupInfo",
      requestType = mls_client.MlsClient.GroupInfoRequest.class,
      responseType = mls_client.MlsClient.GroupInfoResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.GroupInfoRequest,
      mls_client.MlsClient.GroupInfoResponse> getGroupInfoMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.GroupInfoRequest, mls_client.MlsClient.GroupInfoResponse> getGroupInfoMethod;
    if ((getGroupInfoMethod = MLSClientGrpc.getGroupInfoMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getGroupInfoMethod = MLSClientGrpc.getGroupInfoMethod) == null) {
          MLSClientGrpc.getGroupInfoMethod = getGroupInfoMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.GroupInfoRequest, mls_client.MlsClient.GroupInfoResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GroupInfo"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.GroupInfoRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.GroupInfoResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("GroupInfo"))
              .build();
        }
      }
    }
    return getGroupInfoMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.StateAuthRequest,
      mls_client.MlsClient.StateAuthResponse> getStateAuthMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StateAuth",
      requestType = mls_client.MlsClient.StateAuthRequest.class,
      responseType = mls_client.MlsClient.StateAuthResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.StateAuthRequest,
      mls_client.MlsClient.StateAuthResponse> getStateAuthMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.StateAuthRequest, mls_client.MlsClient.StateAuthResponse> getStateAuthMethod;
    if ((getStateAuthMethod = MLSClientGrpc.getStateAuthMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getStateAuthMethod = MLSClientGrpc.getStateAuthMethod) == null) {
          MLSClientGrpc.getStateAuthMethod = getStateAuthMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.StateAuthRequest, mls_client.MlsClient.StateAuthResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StateAuth"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.StateAuthRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.StateAuthResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("StateAuth"))
              .build();
        }
      }
    }
    return getStateAuthMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ExportRequest,
      mls_client.MlsClient.ExportResponse> getExportMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Export",
      requestType = mls_client.MlsClient.ExportRequest.class,
      responseType = mls_client.MlsClient.ExportResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ExportRequest,
      mls_client.MlsClient.ExportResponse> getExportMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ExportRequest, mls_client.MlsClient.ExportResponse> getExportMethod;
    if ((getExportMethod = MLSClientGrpc.getExportMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getExportMethod = MLSClientGrpc.getExportMethod) == null) {
          MLSClientGrpc.getExportMethod = getExportMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ExportRequest, mls_client.MlsClient.ExportResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Export"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExportRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExportResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Export"))
              .build();
        }
      }
    }
    return getExportMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ProtectRequest,
      mls_client.MlsClient.ProtectResponse> getProtectMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Protect",
      requestType = mls_client.MlsClient.ProtectRequest.class,
      responseType = mls_client.MlsClient.ProtectResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ProtectRequest,
      mls_client.MlsClient.ProtectResponse> getProtectMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ProtectRequest, mls_client.MlsClient.ProtectResponse> getProtectMethod;
    if ((getProtectMethod = MLSClientGrpc.getProtectMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getProtectMethod = MLSClientGrpc.getProtectMethod) == null) {
          MLSClientGrpc.getProtectMethod = getProtectMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ProtectRequest, mls_client.MlsClient.ProtectResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Protect"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProtectRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProtectResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Protect"))
              .build();
        }
      }
    }
    return getProtectMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.UnprotectRequest,
      mls_client.MlsClient.UnprotectResponse> getUnprotectMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Unprotect",
      requestType = mls_client.MlsClient.UnprotectRequest.class,
      responseType = mls_client.MlsClient.UnprotectResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.UnprotectRequest,
      mls_client.MlsClient.UnprotectResponse> getUnprotectMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.UnprotectRequest, mls_client.MlsClient.UnprotectResponse> getUnprotectMethod;
    if ((getUnprotectMethod = MLSClientGrpc.getUnprotectMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getUnprotectMethod = MLSClientGrpc.getUnprotectMethod) == null) {
          MLSClientGrpc.getUnprotectMethod = getUnprotectMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.UnprotectRequest, mls_client.MlsClient.UnprotectResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Unprotect"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.UnprotectRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.UnprotectResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Unprotect"))
              .build();
        }
      }
    }
    return getUnprotectMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.StorePSKRequest,
      mls_client.MlsClient.StorePSKResponse> getStorePSKMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StorePSK",
      requestType = mls_client.MlsClient.StorePSKRequest.class,
      responseType = mls_client.MlsClient.StorePSKResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.StorePSKRequest,
      mls_client.MlsClient.StorePSKResponse> getStorePSKMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.StorePSKRequest, mls_client.MlsClient.StorePSKResponse> getStorePSKMethod;
    if ((getStorePSKMethod = MLSClientGrpc.getStorePSKMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getStorePSKMethod = MLSClientGrpc.getStorePSKMethod) == null) {
          MLSClientGrpc.getStorePSKMethod = getStorePSKMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.StorePSKRequest, mls_client.MlsClient.StorePSKResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StorePSK"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.StorePSKRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.StorePSKResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("StorePSK"))
              .build();
        }
      }
    }
    return getStorePSKMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.AddProposalRequest,
      mls_client.MlsClient.ProposalResponse> getAddProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddProposal",
      requestType = mls_client.MlsClient.AddProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.AddProposalRequest,
      mls_client.MlsClient.ProposalResponse> getAddProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.AddProposalRequest, mls_client.MlsClient.ProposalResponse> getAddProposalMethod;
    if ((getAddProposalMethod = MLSClientGrpc.getAddProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getAddProposalMethod = MLSClientGrpc.getAddProposalMethod) == null) {
          MLSClientGrpc.getAddProposalMethod = getAddProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.AddProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.AddProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("AddProposal"))
              .build();
        }
      }
    }
    return getAddProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.UpdateProposalRequest,
      mls_client.MlsClient.ProposalResponse> getUpdateProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateProposal",
      requestType = mls_client.MlsClient.UpdateProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.UpdateProposalRequest,
      mls_client.MlsClient.ProposalResponse> getUpdateProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.UpdateProposalRequest, mls_client.MlsClient.ProposalResponse> getUpdateProposalMethod;
    if ((getUpdateProposalMethod = MLSClientGrpc.getUpdateProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getUpdateProposalMethod = MLSClientGrpc.getUpdateProposalMethod) == null) {
          MLSClientGrpc.getUpdateProposalMethod = getUpdateProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.UpdateProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.UpdateProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("UpdateProposal"))
              .build();
        }
      }
    }
    return getUpdateProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.RemoveProposalRequest,
      mls_client.MlsClient.ProposalResponse> getRemoveProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RemoveProposal",
      requestType = mls_client.MlsClient.RemoveProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.RemoveProposalRequest,
      mls_client.MlsClient.ProposalResponse> getRemoveProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.RemoveProposalRequest, mls_client.MlsClient.ProposalResponse> getRemoveProposalMethod;
    if ((getRemoveProposalMethod = MLSClientGrpc.getRemoveProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getRemoveProposalMethod = MLSClientGrpc.getRemoveProposalMethod) == null) {
          MLSClientGrpc.getRemoveProposalMethod = getRemoveProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.RemoveProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RemoveProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.RemoveProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("RemoveProposal"))
              .build();
        }
      }
    }
    return getRemoveProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalPSKProposalRequest,
      mls_client.MlsClient.ProposalResponse> getExternalPSKProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExternalPSKProposal",
      requestType = mls_client.MlsClient.ExternalPSKProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalPSKProposalRequest,
      mls_client.MlsClient.ProposalResponse> getExternalPSKProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalPSKProposalRequest, mls_client.MlsClient.ProposalResponse> getExternalPSKProposalMethod;
    if ((getExternalPSKProposalMethod = MLSClientGrpc.getExternalPSKProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getExternalPSKProposalMethod = MLSClientGrpc.getExternalPSKProposalMethod) == null) {
          MLSClientGrpc.getExternalPSKProposalMethod = getExternalPSKProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ExternalPSKProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExternalPSKProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExternalPSKProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ExternalPSKProposal"))
              .build();
        }
      }
    }
    return getExternalPSKProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ResumptionPSKProposalRequest,
      mls_client.MlsClient.ProposalResponse> getResumptionPSKProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ResumptionPSKProposal",
      requestType = mls_client.MlsClient.ResumptionPSKProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ResumptionPSKProposalRequest,
      mls_client.MlsClient.ProposalResponse> getResumptionPSKProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ResumptionPSKProposalRequest, mls_client.MlsClient.ProposalResponse> getResumptionPSKProposalMethod;
    if ((getResumptionPSKProposalMethod = MLSClientGrpc.getResumptionPSKProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getResumptionPSKProposalMethod = MLSClientGrpc.getResumptionPSKProposalMethod) == null) {
          MLSClientGrpc.getResumptionPSKProposalMethod = getResumptionPSKProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ResumptionPSKProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ResumptionPSKProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ResumptionPSKProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ResumptionPSKProposal"))
              .build();
        }
      }
    }
    return getResumptionPSKProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.GroupContextExtensionsProposalRequest,
      mls_client.MlsClient.ProposalResponse> getGroupContextExtensionsProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GroupContextExtensionsProposal",
      requestType = mls_client.MlsClient.GroupContextExtensionsProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.GroupContextExtensionsProposalRequest,
      mls_client.MlsClient.ProposalResponse> getGroupContextExtensionsProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.GroupContextExtensionsProposalRequest, mls_client.MlsClient.ProposalResponse> getGroupContextExtensionsProposalMethod;
    if ((getGroupContextExtensionsProposalMethod = MLSClientGrpc.getGroupContextExtensionsProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getGroupContextExtensionsProposalMethod = MLSClientGrpc.getGroupContextExtensionsProposalMethod) == null) {
          MLSClientGrpc.getGroupContextExtensionsProposalMethod = getGroupContextExtensionsProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.GroupContextExtensionsProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GroupContextExtensionsProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.GroupContextExtensionsProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("GroupContextExtensionsProposal"))
              .build();
        }
      }
    }
    return getGroupContextExtensionsProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest,
      mls_client.MlsClient.CommitResponse> getCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Commit",
      requestType = mls_client.MlsClient.CommitRequest.class,
      responseType = mls_client.MlsClient.CommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest,
      mls_client.MlsClient.CommitResponse> getCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest, mls_client.MlsClient.CommitResponse> getCommitMethod;
    if ((getCommitMethod = MLSClientGrpc.getCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getCommitMethod = MLSClientGrpc.getCommitMethod) == null) {
          MLSClientGrpc.getCommitMethod = getCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CommitRequest, mls_client.MlsClient.CommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Commit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Commit"))
              .build();
        }
      }
    }
    return getCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest,
      mls_client.MlsClient.HandleCommitResponse> getHandleCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandleCommit",
      requestType = mls_client.MlsClient.HandleCommitRequest.class,
      responseType = mls_client.MlsClient.HandleCommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest,
      mls_client.MlsClient.HandleCommitResponse> getHandleCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest, mls_client.MlsClient.HandleCommitResponse> getHandleCommitMethod;
    if ((getHandleCommitMethod = MLSClientGrpc.getHandleCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandleCommitMethod = MLSClientGrpc.getHandleCommitMethod) == null) {
          MLSClientGrpc.getHandleCommitMethod = getHandleCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandleCommitRequest, mls_client.MlsClient.HandleCommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandleCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleCommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleCommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandleCommit"))
              .build();
        }
      }
    }
    return getHandleCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest,
      mls_client.MlsClient.HandleCommitResponse> getHandlePendingCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandlePendingCommit",
      requestType = mls_client.MlsClient.HandlePendingCommitRequest.class,
      responseType = mls_client.MlsClient.HandleCommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest,
      mls_client.MlsClient.HandleCommitResponse> getHandlePendingCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest, mls_client.MlsClient.HandleCommitResponse> getHandlePendingCommitMethod;
    if ((getHandlePendingCommitMethod = MLSClientGrpc.getHandlePendingCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandlePendingCommitMethod = MLSClientGrpc.getHandlePendingCommitMethod) == null) {
          MLSClientGrpc.getHandlePendingCommitMethod = getHandlePendingCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandlePendingCommitRequest, mls_client.MlsClient.HandleCommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandlePendingCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandlePendingCommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleCommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandlePendingCommit"))
              .build();
        }
      }
    }
    return getHandlePendingCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitProposalRequest,
      mls_client.MlsClient.ProposalResponse> getReInitProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReInitProposal",
      requestType = mls_client.MlsClient.ReInitProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitProposalRequest,
      mls_client.MlsClient.ProposalResponse> getReInitProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitProposalRequest, mls_client.MlsClient.ProposalResponse> getReInitProposalMethod;
    if ((getReInitProposalMethod = MLSClientGrpc.getReInitProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getReInitProposalMethod = MLSClientGrpc.getReInitProposalMethod) == null) {
          MLSClientGrpc.getReInitProposalMethod = getReInitProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ReInitProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReInitProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ReInitProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ReInitProposal"))
              .build();
        }
      }
    }
    return getReInitProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest,
      mls_client.MlsClient.CommitResponse> getReInitCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReInitCommit",
      requestType = mls_client.MlsClient.CommitRequest.class,
      responseType = mls_client.MlsClient.CommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest,
      mls_client.MlsClient.CommitResponse> getReInitCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CommitRequest, mls_client.MlsClient.CommitResponse> getReInitCommitMethod;
    if ((getReInitCommitMethod = MLSClientGrpc.getReInitCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getReInitCommitMethod = MLSClientGrpc.getReInitCommitMethod) == null) {
          MLSClientGrpc.getReInitCommitMethod = getReInitCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CommitRequest, mls_client.MlsClient.CommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReInitCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ReInitCommit"))
              .build();
        }
      }
    }
    return getReInitCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest,
      mls_client.MlsClient.HandleReInitCommitResponse> getHandlePendingReInitCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandlePendingReInitCommit",
      requestType = mls_client.MlsClient.HandlePendingCommitRequest.class,
      responseType = mls_client.MlsClient.HandleReInitCommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest,
      mls_client.MlsClient.HandleReInitCommitResponse> getHandlePendingReInitCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandlePendingCommitRequest, mls_client.MlsClient.HandleReInitCommitResponse> getHandlePendingReInitCommitMethod;
    if ((getHandlePendingReInitCommitMethod = MLSClientGrpc.getHandlePendingReInitCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandlePendingReInitCommitMethod = MLSClientGrpc.getHandlePendingReInitCommitMethod) == null) {
          MLSClientGrpc.getHandlePendingReInitCommitMethod = getHandlePendingReInitCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandlePendingCommitRequest, mls_client.MlsClient.HandleReInitCommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandlePendingReInitCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandlePendingCommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleReInitCommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandlePendingReInitCommit"))
              .build();
        }
      }
    }
    return getHandlePendingReInitCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest,
      mls_client.MlsClient.HandleReInitCommitResponse> getHandleReInitCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandleReInitCommit",
      requestType = mls_client.MlsClient.HandleCommitRequest.class,
      responseType = mls_client.MlsClient.HandleReInitCommitResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest,
      mls_client.MlsClient.HandleReInitCommitResponse> getHandleReInitCommitMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandleCommitRequest, mls_client.MlsClient.HandleReInitCommitResponse> getHandleReInitCommitMethod;
    if ((getHandleReInitCommitMethod = MLSClientGrpc.getHandleReInitCommitMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandleReInitCommitMethod = MLSClientGrpc.getHandleReInitCommitMethod) == null) {
          MLSClientGrpc.getHandleReInitCommitMethod = getHandleReInitCommitMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandleCommitRequest, mls_client.MlsClient.HandleReInitCommitResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandleReInitCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleCommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleReInitCommitResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandleReInitCommit"))
              .build();
        }
      }
    }
    return getHandleReInitCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitWelcomeRequest,
      mls_client.MlsClient.CreateSubgroupResponse> getReInitWelcomeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReInitWelcome",
      requestType = mls_client.MlsClient.ReInitWelcomeRequest.class,
      responseType = mls_client.MlsClient.CreateSubgroupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitWelcomeRequest,
      mls_client.MlsClient.CreateSubgroupResponse> getReInitWelcomeMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ReInitWelcomeRequest, mls_client.MlsClient.CreateSubgroupResponse> getReInitWelcomeMethod;
    if ((getReInitWelcomeMethod = MLSClientGrpc.getReInitWelcomeMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getReInitWelcomeMethod = MLSClientGrpc.getReInitWelcomeMethod) == null) {
          MLSClientGrpc.getReInitWelcomeMethod = getReInitWelcomeMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ReInitWelcomeRequest, mls_client.MlsClient.CreateSubgroupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReInitWelcome"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ReInitWelcomeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateSubgroupResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ReInitWelcome"))
              .build();
        }
      }
    }
    return getReInitWelcomeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandleReInitWelcomeRequest,
      mls_client.MlsClient.JoinGroupResponse> getHandleReInitWelcomeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandleReInitWelcome",
      requestType = mls_client.MlsClient.HandleReInitWelcomeRequest.class,
      responseType = mls_client.MlsClient.JoinGroupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandleReInitWelcomeRequest,
      mls_client.MlsClient.JoinGroupResponse> getHandleReInitWelcomeMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandleReInitWelcomeRequest, mls_client.MlsClient.JoinGroupResponse> getHandleReInitWelcomeMethod;
    if ((getHandleReInitWelcomeMethod = MLSClientGrpc.getHandleReInitWelcomeMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandleReInitWelcomeMethod = MLSClientGrpc.getHandleReInitWelcomeMethod) == null) {
          MLSClientGrpc.getHandleReInitWelcomeMethod = getHandleReInitWelcomeMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandleReInitWelcomeRequest, mls_client.MlsClient.JoinGroupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandleReInitWelcome"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleReInitWelcomeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.JoinGroupResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandleReInitWelcome"))
              .build();
        }
      }
    }
    return getHandleReInitWelcomeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CreateBranchRequest,
      mls_client.MlsClient.CreateSubgroupResponse> getCreateBranchMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateBranch",
      requestType = mls_client.MlsClient.CreateBranchRequest.class,
      responseType = mls_client.MlsClient.CreateSubgroupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CreateBranchRequest,
      mls_client.MlsClient.CreateSubgroupResponse> getCreateBranchMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CreateBranchRequest, mls_client.MlsClient.CreateSubgroupResponse> getCreateBranchMethod;
    if ((getCreateBranchMethod = MLSClientGrpc.getCreateBranchMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getCreateBranchMethod = MLSClientGrpc.getCreateBranchMethod) == null) {
          MLSClientGrpc.getCreateBranchMethod = getCreateBranchMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CreateBranchRequest, mls_client.MlsClient.CreateSubgroupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateBranch"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateBranchRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateSubgroupResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("CreateBranch"))
              .build();
        }
      }
    }
    return getCreateBranchMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.HandleBranchRequest,
      mls_client.MlsClient.HandleBranchResponse> getHandleBranchMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandleBranch",
      requestType = mls_client.MlsClient.HandleBranchRequest.class,
      responseType = mls_client.MlsClient.HandleBranchResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.HandleBranchRequest,
      mls_client.MlsClient.HandleBranchResponse> getHandleBranchMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.HandleBranchRequest, mls_client.MlsClient.HandleBranchResponse> getHandleBranchMethod;
    if ((getHandleBranchMethod = MLSClientGrpc.getHandleBranchMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getHandleBranchMethod = MLSClientGrpc.getHandleBranchMethod) == null) {
          MLSClientGrpc.getHandleBranchMethod = getHandleBranchMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.HandleBranchRequest, mls_client.MlsClient.HandleBranchResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HandleBranch"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleBranchRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.HandleBranchResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("HandleBranch"))
              .build();
        }
      }
    }
    return getHandleBranchMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.NewMemberAddProposalRequest,
      mls_client.MlsClient.NewMemberAddProposalResponse> getNewMemberAddProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "NewMemberAddProposal",
      requestType = mls_client.MlsClient.NewMemberAddProposalRequest.class,
      responseType = mls_client.MlsClient.NewMemberAddProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.NewMemberAddProposalRequest,
      mls_client.MlsClient.NewMemberAddProposalResponse> getNewMemberAddProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.NewMemberAddProposalRequest, mls_client.MlsClient.NewMemberAddProposalResponse> getNewMemberAddProposalMethod;
    if ((getNewMemberAddProposalMethod = MLSClientGrpc.getNewMemberAddProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getNewMemberAddProposalMethod = MLSClientGrpc.getNewMemberAddProposalMethod) == null) {
          MLSClientGrpc.getNewMemberAddProposalMethod = getNewMemberAddProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.NewMemberAddProposalRequest, mls_client.MlsClient.NewMemberAddProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "NewMemberAddProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.NewMemberAddProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.NewMemberAddProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("NewMemberAddProposal"))
              .build();
        }
      }
    }
    return getNewMemberAddProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.CreateExternalSignerRequest,
      mls_client.MlsClient.CreateExternalSignerResponse> getCreateExternalSignerMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateExternalSigner",
      requestType = mls_client.MlsClient.CreateExternalSignerRequest.class,
      responseType = mls_client.MlsClient.CreateExternalSignerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.CreateExternalSignerRequest,
      mls_client.MlsClient.CreateExternalSignerResponse> getCreateExternalSignerMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.CreateExternalSignerRequest, mls_client.MlsClient.CreateExternalSignerResponse> getCreateExternalSignerMethod;
    if ((getCreateExternalSignerMethod = MLSClientGrpc.getCreateExternalSignerMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getCreateExternalSignerMethod = MLSClientGrpc.getCreateExternalSignerMethod) == null) {
          MLSClientGrpc.getCreateExternalSignerMethod = getCreateExternalSignerMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.CreateExternalSignerRequest, mls_client.MlsClient.CreateExternalSignerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateExternalSigner"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateExternalSignerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.CreateExternalSignerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("CreateExternalSigner"))
              .build();
        }
      }
    }
    return getCreateExternalSignerMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.AddExternalSignerRequest,
      mls_client.MlsClient.ProposalResponse> getAddExternalSignerMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddExternalSigner",
      requestType = mls_client.MlsClient.AddExternalSignerRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.AddExternalSignerRequest,
      mls_client.MlsClient.ProposalResponse> getAddExternalSignerMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.AddExternalSignerRequest, mls_client.MlsClient.ProposalResponse> getAddExternalSignerMethod;
    if ((getAddExternalSignerMethod = MLSClientGrpc.getAddExternalSignerMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getAddExternalSignerMethod = MLSClientGrpc.getAddExternalSignerMethod) == null) {
          MLSClientGrpc.getAddExternalSignerMethod = getAddExternalSignerMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.AddExternalSignerRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddExternalSigner"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.AddExternalSignerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("AddExternalSigner"))
              .build();
        }
      }
    }
    return getAddExternalSignerMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalSignerProposalRequest,
      mls_client.MlsClient.ProposalResponse> getExternalSignerProposalMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExternalSignerProposal",
      requestType = mls_client.MlsClient.ExternalSignerProposalRequest.class,
      responseType = mls_client.MlsClient.ProposalResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalSignerProposalRequest,
      mls_client.MlsClient.ProposalResponse> getExternalSignerProposalMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.ExternalSignerProposalRequest, mls_client.MlsClient.ProposalResponse> getExternalSignerProposalMethod;
    if ((getExternalSignerProposalMethod = MLSClientGrpc.getExternalSignerProposalMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getExternalSignerProposalMethod = MLSClientGrpc.getExternalSignerProposalMethod) == null) {
          MLSClientGrpc.getExternalSignerProposalMethod = getExternalSignerProposalMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.ExternalSignerProposalRequest, mls_client.MlsClient.ProposalResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExternalSignerProposal"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ExternalSignerProposalRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.ProposalResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("ExternalSignerProposal"))
              .build();
        }
      }
    }
    return getExternalSignerProposalMethod;
  }

  private static volatile io.grpc.MethodDescriptor<mls_client.MlsClient.FreeRequest,
      mls_client.MlsClient.FreeResponse> getFreeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Free",
      requestType = mls_client.MlsClient.FreeRequest.class,
      responseType = mls_client.MlsClient.FreeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<mls_client.MlsClient.FreeRequest,
      mls_client.MlsClient.FreeResponse> getFreeMethod() {
    io.grpc.MethodDescriptor<mls_client.MlsClient.FreeRequest, mls_client.MlsClient.FreeResponse> getFreeMethod;
    if ((getFreeMethod = MLSClientGrpc.getFreeMethod) == null) {
      synchronized (MLSClientGrpc.class) {
        if ((getFreeMethod = MLSClientGrpc.getFreeMethod) == null) {
          MLSClientGrpc.getFreeMethod = getFreeMethod =
              io.grpc.MethodDescriptor.<mls_client.MlsClient.FreeRequest, mls_client.MlsClient.FreeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Free"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.FreeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  mls_client.MlsClient.FreeResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MLSClientMethodDescriptorSupplier("Free"))
              .build();
        }
      }
    }
    return getFreeMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static MLSClientStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MLSClientStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MLSClientStub>() {
        @java.lang.Override
        public MLSClientStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MLSClientStub(channel, callOptions);
        }
      };
    return MLSClientStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static MLSClientBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MLSClientBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MLSClientBlockingStub>() {
        @java.lang.Override
        public MLSClientBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MLSClientBlockingStub(channel, callOptions);
        }
      };
    return MLSClientBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static MLSClientFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MLSClientFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MLSClientFutureStub>() {
        @java.lang.Override
        public MLSClientFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MLSClientFutureStub(channel, callOptions);
        }
      };
    return MLSClientFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * A wrapper around an MLS client implementation
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * The human-readable name of the stack
     * </pre>
     */
    default void name(mls_client.MlsClient.NameRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.NameResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNameMethod(), responseObserver);
    }

    /**
     * <pre>
     * List of supported ciphersuites
     * </pre>
     */
    default void supportedCiphersuites(mls_client.MlsClient.SupportedCiphersuitesRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.SupportedCiphersuitesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSupportedCiphersuitesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Ways to become a member of a group
     * </pre>
     */
    default void createGroup(mls_client.MlsClient.CreateGroupRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateGroupResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateGroupMethod(), responseObserver);
    }

    /**
     */
    default void createKeyPackage(mls_client.MlsClient.CreateKeyPackageRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateKeyPackageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateKeyPackageMethod(), responseObserver);
    }

    /**
     */
    default void joinGroup(mls_client.MlsClient.JoinGroupRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getJoinGroupMethod(), responseObserver);
    }

    /**
     */
    default void externalJoin(mls_client.MlsClient.ExternalJoinRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ExternalJoinResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExternalJoinMethod(), responseObserver);
    }

    /**
     * <pre>
     * Operations using a group state
     * </pre>
     */
    default void groupInfo(mls_client.MlsClient.GroupInfoRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.GroupInfoResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGroupInfoMethod(), responseObserver);
    }

    /**
     */
    default void stateAuth(mls_client.MlsClient.StateAuthRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.StateAuthResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStateAuthMethod(), responseObserver);
    }

    /**
     */
    default void export(mls_client.MlsClient.ExportRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ExportResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExportMethod(), responseObserver);
    }

    /**
     */
    default void protect(mls_client.MlsClient.ProtectRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProtectResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getProtectMethod(), responseObserver);
    }

    /**
     */
    default void unprotect(mls_client.MlsClient.UnprotectRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.UnprotectResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUnprotectMethod(), responseObserver);
    }

    /**
     */
    default void storePSK(mls_client.MlsClient.StorePSKRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.StorePSKResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStorePSKMethod(), responseObserver);
    }

    /**
     */
    default void addProposal(mls_client.MlsClient.AddProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddProposalMethod(), responseObserver);
    }

    /**
     */
    default void updateProposal(mls_client.MlsClient.UpdateProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateProposalMethod(), responseObserver);
    }

    /**
     */
    default void removeProposal(mls_client.MlsClient.RemoveProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRemoveProposalMethod(), responseObserver);
    }

    /**
     */
    default void externalPSKProposal(mls_client.MlsClient.ExternalPSKProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExternalPSKProposalMethod(), responseObserver);
    }

    /**
     */
    default void resumptionPSKProposal(mls_client.MlsClient.ResumptionPSKProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getResumptionPSKProposalMethod(), responseObserver);
    }

    /**
     */
    default void groupContextExtensionsProposal(mls_client.MlsClient.GroupContextExtensionsProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGroupContextExtensionsProposalMethod(), responseObserver);
    }

    /**
     */
    default void commit(mls_client.MlsClient.CommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCommitMethod(), responseObserver);
    }

    /**
     */
    default void handleCommit(mls_client.MlsClient.HandleCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandleCommitMethod(), responseObserver);
    }

    /**
     */
    default void handlePendingCommit(mls_client.MlsClient.HandlePendingCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandlePendingCommitMethod(), responseObserver);
    }

    /**
     * <pre>
     * Reinitialization
     * </pre>
     */
    default void reInitProposal(mls_client.MlsClient.ReInitProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReInitProposalMethod(), responseObserver);
    }

    /**
     */
    default void reInitCommit(mls_client.MlsClient.CommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReInitCommitMethod(), responseObserver);
    }

    /**
     */
    default void handlePendingReInitCommit(mls_client.MlsClient.HandlePendingCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandlePendingReInitCommitMethod(), responseObserver);
    }

    /**
     */
    default void handleReInitCommit(mls_client.MlsClient.HandleCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandleReInitCommitMethod(), responseObserver);
    }

    /**
     */
    default void reInitWelcome(mls_client.MlsClient.ReInitWelcomeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReInitWelcomeMethod(), responseObserver);
    }

    /**
     */
    default void handleReInitWelcome(mls_client.MlsClient.HandleReInitWelcomeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandleReInitWelcomeMethod(), responseObserver);
    }

    /**
     * <pre>
     * Subgroup Branching
     * </pre>
     */
    default void createBranch(mls_client.MlsClient.CreateBranchRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateBranchMethod(), responseObserver);
    }

    /**
     */
    default void handleBranch(mls_client.MlsClient.HandleBranchRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleBranchResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHandleBranchMethod(), responseObserver);
    }

    /**
     * <pre>
     * External proposals
     * </pre>
     */
    default void newMemberAddProposal(mls_client.MlsClient.NewMemberAddProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.NewMemberAddProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNewMemberAddProposalMethod(), responseObserver);
    }

    /**
     */
    default void createExternalSigner(mls_client.MlsClient.CreateExternalSignerRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateExternalSignerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateExternalSignerMethod(), responseObserver);
    }

    /**
     */
    default void addExternalSigner(mls_client.MlsClient.AddExternalSignerRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddExternalSignerMethod(), responseObserver);
    }

    /**
     */
    default void externalSignerProposal(mls_client.MlsClient.ExternalSignerProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExternalSignerProposalMethod(), responseObserver);
    }

    /**
     * <pre>
     * Cleanup
     * </pre>
     */
    default void free(mls_client.MlsClient.FreeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.FreeResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getFreeMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service MLSClient.
   * <pre>
   * A wrapper around an MLS client implementation
   * </pre>
   */
  public static abstract class MLSClientImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return MLSClientGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service MLSClient.
   * <pre>
   * A wrapper around an MLS client implementation
   * </pre>
   */
  public static final class MLSClientStub
      extends io.grpc.stub.AbstractAsyncStub<MLSClientStub> {
    private MLSClientStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MLSClientStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MLSClientStub(channel, callOptions);
    }

    /**
     * <pre>
     * The human-readable name of the stack
     * </pre>
     */
    public void name(mls_client.MlsClient.NameRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.NameResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getNameMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * List of supported ciphersuites
     * </pre>
     */
    public void supportedCiphersuites(mls_client.MlsClient.SupportedCiphersuitesRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.SupportedCiphersuitesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSupportedCiphersuitesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Ways to become a member of a group
     * </pre>
     */
    public void createGroup(mls_client.MlsClient.CreateGroupRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateGroupResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createKeyPackage(mls_client.MlsClient.CreateKeyPackageRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateKeyPackageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateKeyPackageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void joinGroup(mls_client.MlsClient.JoinGroupRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getJoinGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void externalJoin(mls_client.MlsClient.ExternalJoinRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ExternalJoinResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExternalJoinMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Operations using a group state
     * </pre>
     */
    public void groupInfo(mls_client.MlsClient.GroupInfoRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.GroupInfoResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGroupInfoMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void stateAuth(mls_client.MlsClient.StateAuthRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.StateAuthResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStateAuthMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void export(mls_client.MlsClient.ExportRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ExportResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExportMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void protect(mls_client.MlsClient.ProtectRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProtectResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getProtectMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void unprotect(mls_client.MlsClient.UnprotectRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.UnprotectResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUnprotectMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void storePSK(mls_client.MlsClient.StorePSKRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.StorePSKResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStorePSKMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void addProposal(mls_client.MlsClient.AddProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateProposal(mls_client.MlsClient.UpdateProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void removeProposal(mls_client.MlsClient.RemoveProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRemoveProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void externalPSKProposal(mls_client.MlsClient.ExternalPSKProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExternalPSKProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void resumptionPSKProposal(mls_client.MlsClient.ResumptionPSKProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getResumptionPSKProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void groupContextExtensionsProposal(mls_client.MlsClient.GroupContextExtensionsProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGroupContextExtensionsProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void commit(mls_client.MlsClient.CommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handleCommit(mls_client.MlsClient.HandleCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandleCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handlePendingCommit(mls_client.MlsClient.HandlePendingCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandlePendingCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Reinitialization
     * </pre>
     */
    public void reInitProposal(mls_client.MlsClient.ReInitProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReInitProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void reInitCommit(mls_client.MlsClient.CommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReInitCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handlePendingReInitCommit(mls_client.MlsClient.HandlePendingCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandlePendingReInitCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handleReInitCommit(mls_client.MlsClient.HandleCommitRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandleReInitCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void reInitWelcome(mls_client.MlsClient.ReInitWelcomeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReInitWelcomeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handleReInitWelcome(mls_client.MlsClient.HandleReInitWelcomeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandleReInitWelcomeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Subgroup Branching
     * </pre>
     */
    public void createBranch(mls_client.MlsClient.CreateBranchRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateBranchMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handleBranch(mls_client.MlsClient.HandleBranchRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleBranchResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHandleBranchMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * External proposals
     * </pre>
     */
    public void newMemberAddProposal(mls_client.MlsClient.NewMemberAddProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.NewMemberAddProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getNewMemberAddProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createExternalSigner(mls_client.MlsClient.CreateExternalSignerRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateExternalSignerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateExternalSignerMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void addExternalSigner(mls_client.MlsClient.AddExternalSignerRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddExternalSignerMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void externalSignerProposal(mls_client.MlsClient.ExternalSignerProposalRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExternalSignerProposalMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Cleanup
     * </pre>
     */
    public void free(mls_client.MlsClient.FreeRequest request,
        io.grpc.stub.StreamObserver<mls_client.MlsClient.FreeResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getFreeMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service MLSClient.
   * <pre>
   * A wrapper around an MLS client implementation
   * </pre>
   */
  public static final class MLSClientBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<MLSClientBlockingStub> {
    private MLSClientBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MLSClientBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MLSClientBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * The human-readable name of the stack
     * </pre>
     */
    public mls_client.MlsClient.NameResponse name(mls_client.MlsClient.NameRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getNameMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * List of supported ciphersuites
     * </pre>
     */
    public mls_client.MlsClient.SupportedCiphersuitesResponse supportedCiphersuites(mls_client.MlsClient.SupportedCiphersuitesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSupportedCiphersuitesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Ways to become a member of a group
     * </pre>
     */
    public mls_client.MlsClient.CreateGroupResponse createGroup(mls_client.MlsClient.CreateGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.CreateKeyPackageResponse createKeyPackage(mls_client.MlsClient.CreateKeyPackageRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateKeyPackageMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.JoinGroupResponse joinGroup(mls_client.MlsClient.JoinGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getJoinGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ExternalJoinResponse externalJoin(mls_client.MlsClient.ExternalJoinRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExternalJoinMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Operations using a group state
     * </pre>
     */
    public mls_client.MlsClient.GroupInfoResponse groupInfo(mls_client.MlsClient.GroupInfoRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGroupInfoMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.StateAuthResponse stateAuth(mls_client.MlsClient.StateAuthRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStateAuthMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ExportResponse export(mls_client.MlsClient.ExportRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExportMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProtectResponse protect(mls_client.MlsClient.ProtectRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getProtectMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.UnprotectResponse unprotect(mls_client.MlsClient.UnprotectRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUnprotectMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.StorePSKResponse storePSK(mls_client.MlsClient.StorePSKRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStorePSKMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse addProposal(mls_client.MlsClient.AddProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse updateProposal(mls_client.MlsClient.UpdateProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse removeProposal(mls_client.MlsClient.RemoveProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRemoveProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse externalPSKProposal(mls_client.MlsClient.ExternalPSKProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExternalPSKProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse resumptionPSKProposal(mls_client.MlsClient.ResumptionPSKProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getResumptionPSKProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse groupContextExtensionsProposal(mls_client.MlsClient.GroupContextExtensionsProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGroupContextExtensionsProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.CommitResponse commit(mls_client.MlsClient.CommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.HandleCommitResponse handleCommit(mls_client.MlsClient.HandleCommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandleCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.HandleCommitResponse handlePendingCommit(mls_client.MlsClient.HandlePendingCommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandlePendingCommitMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Reinitialization
     * </pre>
     */
    public mls_client.MlsClient.ProposalResponse reInitProposal(mls_client.MlsClient.ReInitProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReInitProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.CommitResponse reInitCommit(mls_client.MlsClient.CommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReInitCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.HandleReInitCommitResponse handlePendingReInitCommit(mls_client.MlsClient.HandlePendingCommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandlePendingReInitCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.HandleReInitCommitResponse handleReInitCommit(mls_client.MlsClient.HandleCommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandleReInitCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.CreateSubgroupResponse reInitWelcome(mls_client.MlsClient.ReInitWelcomeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReInitWelcomeMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.JoinGroupResponse handleReInitWelcome(mls_client.MlsClient.HandleReInitWelcomeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandleReInitWelcomeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Subgroup Branching
     * </pre>
     */
    public mls_client.MlsClient.CreateSubgroupResponse createBranch(mls_client.MlsClient.CreateBranchRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateBranchMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.HandleBranchResponse handleBranch(mls_client.MlsClient.HandleBranchRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHandleBranchMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * External proposals
     * </pre>
     */
    public mls_client.MlsClient.NewMemberAddProposalResponse newMemberAddProposal(mls_client.MlsClient.NewMemberAddProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getNewMemberAddProposalMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.CreateExternalSignerResponse createExternalSigner(mls_client.MlsClient.CreateExternalSignerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateExternalSignerMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse addExternalSigner(mls_client.MlsClient.AddExternalSignerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddExternalSignerMethod(), getCallOptions(), request);
    }

    /**
     */
    public mls_client.MlsClient.ProposalResponse externalSignerProposal(mls_client.MlsClient.ExternalSignerProposalRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExternalSignerProposalMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Cleanup
     * </pre>
     */
    public mls_client.MlsClient.FreeResponse free(mls_client.MlsClient.FreeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getFreeMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service MLSClient.
   * <pre>
   * A wrapper around an MLS client implementation
   * </pre>
   */
  public static final class MLSClientFutureStub
      extends io.grpc.stub.AbstractFutureStub<MLSClientFutureStub> {
    private MLSClientFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MLSClientFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MLSClientFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * The human-readable name of the stack
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.NameResponse> name(
        mls_client.MlsClient.NameRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getNameMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * List of supported ciphersuites
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.SupportedCiphersuitesResponse> supportedCiphersuites(
        mls_client.MlsClient.SupportedCiphersuitesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSupportedCiphersuitesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Ways to become a member of a group
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CreateGroupResponse> createGroup(
        mls_client.MlsClient.CreateGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CreateKeyPackageResponse> createKeyPackage(
        mls_client.MlsClient.CreateKeyPackageRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateKeyPackageMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.JoinGroupResponse> joinGroup(
        mls_client.MlsClient.JoinGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getJoinGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ExternalJoinResponse> externalJoin(
        mls_client.MlsClient.ExternalJoinRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExternalJoinMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Operations using a group state
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.GroupInfoResponse> groupInfo(
        mls_client.MlsClient.GroupInfoRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGroupInfoMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.StateAuthResponse> stateAuth(
        mls_client.MlsClient.StateAuthRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStateAuthMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ExportResponse> export(
        mls_client.MlsClient.ExportRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExportMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProtectResponse> protect(
        mls_client.MlsClient.ProtectRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getProtectMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.UnprotectResponse> unprotect(
        mls_client.MlsClient.UnprotectRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUnprotectMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.StorePSKResponse> storePSK(
        mls_client.MlsClient.StorePSKRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStorePSKMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> addProposal(
        mls_client.MlsClient.AddProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> updateProposal(
        mls_client.MlsClient.UpdateProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> removeProposal(
        mls_client.MlsClient.RemoveProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRemoveProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> externalPSKProposal(
        mls_client.MlsClient.ExternalPSKProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExternalPSKProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> resumptionPSKProposal(
        mls_client.MlsClient.ResumptionPSKProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getResumptionPSKProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> groupContextExtensionsProposal(
        mls_client.MlsClient.GroupContextExtensionsProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGroupContextExtensionsProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CommitResponse> commit(
        mls_client.MlsClient.CommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.HandleCommitResponse> handleCommit(
        mls_client.MlsClient.HandleCommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandleCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.HandleCommitResponse> handlePendingCommit(
        mls_client.MlsClient.HandlePendingCommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandlePendingCommitMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Reinitialization
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> reInitProposal(
        mls_client.MlsClient.ReInitProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReInitProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CommitResponse> reInitCommit(
        mls_client.MlsClient.CommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReInitCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.HandleReInitCommitResponse> handlePendingReInitCommit(
        mls_client.MlsClient.HandlePendingCommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandlePendingReInitCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.HandleReInitCommitResponse> handleReInitCommit(
        mls_client.MlsClient.HandleCommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandleReInitCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CreateSubgroupResponse> reInitWelcome(
        mls_client.MlsClient.ReInitWelcomeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReInitWelcomeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.JoinGroupResponse> handleReInitWelcome(
        mls_client.MlsClient.HandleReInitWelcomeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandleReInitWelcomeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Subgroup Branching
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CreateSubgroupResponse> createBranch(
        mls_client.MlsClient.CreateBranchRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateBranchMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.HandleBranchResponse> handleBranch(
        mls_client.MlsClient.HandleBranchRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHandleBranchMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * External proposals
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.NewMemberAddProposalResponse> newMemberAddProposal(
        mls_client.MlsClient.NewMemberAddProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getNewMemberAddProposalMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.CreateExternalSignerResponse> createExternalSigner(
        mls_client.MlsClient.CreateExternalSignerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateExternalSignerMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> addExternalSigner(
        mls_client.MlsClient.AddExternalSignerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddExternalSignerMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.ProposalResponse> externalSignerProposal(
        mls_client.MlsClient.ExternalSignerProposalRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExternalSignerProposalMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Cleanup
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<mls_client.MlsClient.FreeResponse> free(
        mls_client.MlsClient.FreeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getFreeMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_NAME = 0;
  private static final int METHODID_SUPPORTED_CIPHERSUITES = 1;
  private static final int METHODID_CREATE_GROUP = 2;
  private static final int METHODID_CREATE_KEY_PACKAGE = 3;
  private static final int METHODID_JOIN_GROUP = 4;
  private static final int METHODID_EXTERNAL_JOIN = 5;
  private static final int METHODID_GROUP_INFO = 6;
  private static final int METHODID_STATE_AUTH = 7;
  private static final int METHODID_EXPORT = 8;
  private static final int METHODID_PROTECT = 9;
  private static final int METHODID_UNPROTECT = 10;
  private static final int METHODID_STORE_PSK = 11;
  private static final int METHODID_ADD_PROPOSAL = 12;
  private static final int METHODID_UPDATE_PROPOSAL = 13;
  private static final int METHODID_REMOVE_PROPOSAL = 14;
  private static final int METHODID_EXTERNAL_PSKPROPOSAL = 15;
  private static final int METHODID_RESUMPTION_PSKPROPOSAL = 16;
  private static final int METHODID_GROUP_CONTEXT_EXTENSIONS_PROPOSAL = 17;
  private static final int METHODID_COMMIT = 18;
  private static final int METHODID_HANDLE_COMMIT = 19;
  private static final int METHODID_HANDLE_PENDING_COMMIT = 20;
  private static final int METHODID_RE_INIT_PROPOSAL = 21;
  private static final int METHODID_RE_INIT_COMMIT = 22;
  private static final int METHODID_HANDLE_PENDING_RE_INIT_COMMIT = 23;
  private static final int METHODID_HANDLE_RE_INIT_COMMIT = 24;
  private static final int METHODID_RE_INIT_WELCOME = 25;
  private static final int METHODID_HANDLE_RE_INIT_WELCOME = 26;
  private static final int METHODID_CREATE_BRANCH = 27;
  private static final int METHODID_HANDLE_BRANCH = 28;
  private static final int METHODID_NEW_MEMBER_ADD_PROPOSAL = 29;
  private static final int METHODID_CREATE_EXTERNAL_SIGNER = 30;
  private static final int METHODID_ADD_EXTERNAL_SIGNER = 31;
  private static final int METHODID_EXTERNAL_SIGNER_PROPOSAL = 32;
  private static final int METHODID_FREE = 33;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_NAME:
          serviceImpl.name((mls_client.MlsClient.NameRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.NameResponse>) responseObserver);
          break;
        case METHODID_SUPPORTED_CIPHERSUITES:
          serviceImpl.supportedCiphersuites((mls_client.MlsClient.SupportedCiphersuitesRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.SupportedCiphersuitesResponse>) responseObserver);
          break;
        case METHODID_CREATE_GROUP:
          serviceImpl.createGroup((mls_client.MlsClient.CreateGroupRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateGroupResponse>) responseObserver);
          break;
        case METHODID_CREATE_KEY_PACKAGE:
          serviceImpl.createKeyPackage((mls_client.MlsClient.CreateKeyPackageRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateKeyPackageResponse>) responseObserver);
          break;
        case METHODID_JOIN_GROUP:
          serviceImpl.joinGroup((mls_client.MlsClient.JoinGroupRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse>) responseObserver);
          break;
        case METHODID_EXTERNAL_JOIN:
          serviceImpl.externalJoin((mls_client.MlsClient.ExternalJoinRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ExternalJoinResponse>) responseObserver);
          break;
        case METHODID_GROUP_INFO:
          serviceImpl.groupInfo((mls_client.MlsClient.GroupInfoRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.GroupInfoResponse>) responseObserver);
          break;
        case METHODID_STATE_AUTH:
          serviceImpl.stateAuth((mls_client.MlsClient.StateAuthRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.StateAuthResponse>) responseObserver);
          break;
        case METHODID_EXPORT:
          serviceImpl.export((mls_client.MlsClient.ExportRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ExportResponse>) responseObserver);
          break;
        case METHODID_PROTECT:
          serviceImpl.protect((mls_client.MlsClient.ProtectRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProtectResponse>) responseObserver);
          break;
        case METHODID_UNPROTECT:
          serviceImpl.unprotect((mls_client.MlsClient.UnprotectRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.UnprotectResponse>) responseObserver);
          break;
        case METHODID_STORE_PSK:
          serviceImpl.storePSK((mls_client.MlsClient.StorePSKRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.StorePSKResponse>) responseObserver);
          break;
        case METHODID_ADD_PROPOSAL:
          serviceImpl.addProposal((mls_client.MlsClient.AddProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_UPDATE_PROPOSAL:
          serviceImpl.updateProposal((mls_client.MlsClient.UpdateProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_REMOVE_PROPOSAL:
          serviceImpl.removeProposal((mls_client.MlsClient.RemoveProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_EXTERNAL_PSKPROPOSAL:
          serviceImpl.externalPSKProposal((mls_client.MlsClient.ExternalPSKProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_RESUMPTION_PSKPROPOSAL:
          serviceImpl.resumptionPSKProposal((mls_client.MlsClient.ResumptionPSKProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_GROUP_CONTEXT_EXTENSIONS_PROPOSAL:
          serviceImpl.groupContextExtensionsProposal((mls_client.MlsClient.GroupContextExtensionsProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_COMMIT:
          serviceImpl.commit((mls_client.MlsClient.CommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse>) responseObserver);
          break;
        case METHODID_HANDLE_COMMIT:
          serviceImpl.handleCommit((mls_client.MlsClient.HandleCommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse>) responseObserver);
          break;
        case METHODID_HANDLE_PENDING_COMMIT:
          serviceImpl.handlePendingCommit((mls_client.MlsClient.HandlePendingCommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleCommitResponse>) responseObserver);
          break;
        case METHODID_RE_INIT_PROPOSAL:
          serviceImpl.reInitProposal((mls_client.MlsClient.ReInitProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_RE_INIT_COMMIT:
          serviceImpl.reInitCommit((mls_client.MlsClient.CommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CommitResponse>) responseObserver);
          break;
        case METHODID_HANDLE_PENDING_RE_INIT_COMMIT:
          serviceImpl.handlePendingReInitCommit((mls_client.MlsClient.HandlePendingCommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse>) responseObserver);
          break;
        case METHODID_HANDLE_RE_INIT_COMMIT:
          serviceImpl.handleReInitCommit((mls_client.MlsClient.HandleCommitRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleReInitCommitResponse>) responseObserver);
          break;
        case METHODID_RE_INIT_WELCOME:
          serviceImpl.reInitWelcome((mls_client.MlsClient.ReInitWelcomeRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse>) responseObserver);
          break;
        case METHODID_HANDLE_RE_INIT_WELCOME:
          serviceImpl.handleReInitWelcome((mls_client.MlsClient.HandleReInitWelcomeRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.JoinGroupResponse>) responseObserver);
          break;
        case METHODID_CREATE_BRANCH:
          serviceImpl.createBranch((mls_client.MlsClient.CreateBranchRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateSubgroupResponse>) responseObserver);
          break;
        case METHODID_HANDLE_BRANCH:
          serviceImpl.handleBranch((mls_client.MlsClient.HandleBranchRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.HandleBranchResponse>) responseObserver);
          break;
        case METHODID_NEW_MEMBER_ADD_PROPOSAL:
          serviceImpl.newMemberAddProposal((mls_client.MlsClient.NewMemberAddProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.NewMemberAddProposalResponse>) responseObserver);
          break;
        case METHODID_CREATE_EXTERNAL_SIGNER:
          serviceImpl.createExternalSigner((mls_client.MlsClient.CreateExternalSignerRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.CreateExternalSignerResponse>) responseObserver);
          break;
        case METHODID_ADD_EXTERNAL_SIGNER:
          serviceImpl.addExternalSigner((mls_client.MlsClient.AddExternalSignerRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_EXTERNAL_SIGNER_PROPOSAL:
          serviceImpl.externalSignerProposal((mls_client.MlsClient.ExternalSignerProposalRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.ProposalResponse>) responseObserver);
          break;
        case METHODID_FREE:
          serviceImpl.free((mls_client.MlsClient.FreeRequest) request,
              (io.grpc.stub.StreamObserver<mls_client.MlsClient.FreeResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getNameMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.NameRequest,
              mls_client.MlsClient.NameResponse>(
                service, METHODID_NAME)))
        .addMethod(
          getSupportedCiphersuitesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.SupportedCiphersuitesRequest,
              mls_client.MlsClient.SupportedCiphersuitesResponse>(
                service, METHODID_SUPPORTED_CIPHERSUITES)))
        .addMethod(
          getCreateGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CreateGroupRequest,
              mls_client.MlsClient.CreateGroupResponse>(
                service, METHODID_CREATE_GROUP)))
        .addMethod(
          getCreateKeyPackageMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CreateKeyPackageRequest,
              mls_client.MlsClient.CreateKeyPackageResponse>(
                service, METHODID_CREATE_KEY_PACKAGE)))
        .addMethod(
          getJoinGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.JoinGroupRequest,
              mls_client.MlsClient.JoinGroupResponse>(
                service, METHODID_JOIN_GROUP)))
        .addMethod(
          getExternalJoinMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ExternalJoinRequest,
              mls_client.MlsClient.ExternalJoinResponse>(
                service, METHODID_EXTERNAL_JOIN)))
        .addMethod(
          getGroupInfoMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.GroupInfoRequest,
              mls_client.MlsClient.GroupInfoResponse>(
                service, METHODID_GROUP_INFO)))
        .addMethod(
          getStateAuthMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.StateAuthRequest,
              mls_client.MlsClient.StateAuthResponse>(
                service, METHODID_STATE_AUTH)))
        .addMethod(
          getExportMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ExportRequest,
              mls_client.MlsClient.ExportResponse>(
                service, METHODID_EXPORT)))
        .addMethod(
          getProtectMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ProtectRequest,
              mls_client.MlsClient.ProtectResponse>(
                service, METHODID_PROTECT)))
        .addMethod(
          getUnprotectMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.UnprotectRequest,
              mls_client.MlsClient.UnprotectResponse>(
                service, METHODID_UNPROTECT)))
        .addMethod(
          getStorePSKMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.StorePSKRequest,
              mls_client.MlsClient.StorePSKResponse>(
                service, METHODID_STORE_PSK)))
        .addMethod(
          getAddProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.AddProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_ADD_PROPOSAL)))
        .addMethod(
          getUpdateProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.UpdateProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_UPDATE_PROPOSAL)))
        .addMethod(
          getRemoveProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.RemoveProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_REMOVE_PROPOSAL)))
        .addMethod(
          getExternalPSKProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ExternalPSKProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_EXTERNAL_PSKPROPOSAL)))
        .addMethod(
          getResumptionPSKProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ResumptionPSKProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_RESUMPTION_PSKPROPOSAL)))
        .addMethod(
          getGroupContextExtensionsProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.GroupContextExtensionsProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_GROUP_CONTEXT_EXTENSIONS_PROPOSAL)))
        .addMethod(
          getCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CommitRequest,
              mls_client.MlsClient.CommitResponse>(
                service, METHODID_COMMIT)))
        .addMethod(
          getHandleCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandleCommitRequest,
              mls_client.MlsClient.HandleCommitResponse>(
                service, METHODID_HANDLE_COMMIT)))
        .addMethod(
          getHandlePendingCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandlePendingCommitRequest,
              mls_client.MlsClient.HandleCommitResponse>(
                service, METHODID_HANDLE_PENDING_COMMIT)))
        .addMethod(
          getReInitProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ReInitProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_RE_INIT_PROPOSAL)))
        .addMethod(
          getReInitCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CommitRequest,
              mls_client.MlsClient.CommitResponse>(
                service, METHODID_RE_INIT_COMMIT)))
        .addMethod(
          getHandlePendingReInitCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandlePendingCommitRequest,
              mls_client.MlsClient.HandleReInitCommitResponse>(
                service, METHODID_HANDLE_PENDING_RE_INIT_COMMIT)))
        .addMethod(
          getHandleReInitCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandleCommitRequest,
              mls_client.MlsClient.HandleReInitCommitResponse>(
                service, METHODID_HANDLE_RE_INIT_COMMIT)))
        .addMethod(
          getReInitWelcomeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ReInitWelcomeRequest,
              mls_client.MlsClient.CreateSubgroupResponse>(
                service, METHODID_RE_INIT_WELCOME)))
        .addMethod(
          getHandleReInitWelcomeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandleReInitWelcomeRequest,
              mls_client.MlsClient.JoinGroupResponse>(
                service, METHODID_HANDLE_RE_INIT_WELCOME)))
        .addMethod(
          getCreateBranchMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CreateBranchRequest,
              mls_client.MlsClient.CreateSubgroupResponse>(
                service, METHODID_CREATE_BRANCH)))
        .addMethod(
          getHandleBranchMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.HandleBranchRequest,
              mls_client.MlsClient.HandleBranchResponse>(
                service, METHODID_HANDLE_BRANCH)))
        .addMethod(
          getNewMemberAddProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.NewMemberAddProposalRequest,
              mls_client.MlsClient.NewMemberAddProposalResponse>(
                service, METHODID_NEW_MEMBER_ADD_PROPOSAL)))
        .addMethod(
          getCreateExternalSignerMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.CreateExternalSignerRequest,
              mls_client.MlsClient.CreateExternalSignerResponse>(
                service, METHODID_CREATE_EXTERNAL_SIGNER)))
        .addMethod(
          getAddExternalSignerMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.AddExternalSignerRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_ADD_EXTERNAL_SIGNER)))
        .addMethod(
          getExternalSignerProposalMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.ExternalSignerProposalRequest,
              mls_client.MlsClient.ProposalResponse>(
                service, METHODID_EXTERNAL_SIGNER_PROPOSAL)))
        .addMethod(
          getFreeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              mls_client.MlsClient.FreeRequest,
              mls_client.MlsClient.FreeResponse>(
                service, METHODID_FREE)))
        .build();
  }

  private static abstract class MLSClientBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    MLSClientBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return mls_client.MlsClient.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("MLSClient");
    }
  }

  private static final class MLSClientFileDescriptorSupplier
      extends MLSClientBaseDescriptorSupplier {
    MLSClientFileDescriptorSupplier() {}
  }

  private static final class MLSClientMethodDescriptorSupplier
      extends MLSClientBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    MLSClientMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (MLSClientGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new MLSClientFileDescriptorSupplier())
              .addMethod(getNameMethod())
              .addMethod(getSupportedCiphersuitesMethod())
              .addMethod(getCreateGroupMethod())
              .addMethod(getCreateKeyPackageMethod())
              .addMethod(getJoinGroupMethod())
              .addMethod(getExternalJoinMethod())
              .addMethod(getGroupInfoMethod())
              .addMethod(getStateAuthMethod())
              .addMethod(getExportMethod())
              .addMethod(getProtectMethod())
              .addMethod(getUnprotectMethod())
              .addMethod(getStorePSKMethod())
              .addMethod(getAddProposalMethod())
              .addMethod(getUpdateProposalMethod())
              .addMethod(getRemoveProposalMethod())
              .addMethod(getExternalPSKProposalMethod())
              .addMethod(getResumptionPSKProposalMethod())
              .addMethod(getGroupContextExtensionsProposalMethod())
              .addMethod(getCommitMethod())
              .addMethod(getHandleCommitMethod())
              .addMethod(getHandlePendingCommitMethod())
              .addMethod(getReInitProposalMethod())
              .addMethod(getReInitCommitMethod())
              .addMethod(getHandlePendingReInitCommitMethod())
              .addMethod(getHandleReInitCommitMethod())
              .addMethod(getReInitWelcomeMethod())
              .addMethod(getHandleReInitWelcomeMethod())
              .addMethod(getCreateBranchMethod())
              .addMethod(getHandleBranchMethod())
              .addMethod(getNewMemberAddProposalMethod())
              .addMethod(getCreateExternalSignerMethod())
              .addMethod(getAddExternalSignerMethod())
              .addMethod(getExternalSignerProposalMethod())
              .addMethod(getFreeMethod())
              .build();
        }
      }
    }
    return result;
  }
}
